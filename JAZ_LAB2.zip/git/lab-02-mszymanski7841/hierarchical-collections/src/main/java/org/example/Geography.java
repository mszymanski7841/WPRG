package org.example;

import org.example.model.abstraction.IHaveHierarchicalStructure;

public class Geography implements IHaveHierarchicalStructure <Geography> {
    int id;
    String name;
    String type;
    String code;
    Integer parentId;

//    public Geography(int id, String name, String type, String code, Integer parentId){
//        this.id = id;
//        this.name = name;
//        this.type = type;
//        this.code = code;
//        this.parentId = parentId;
//    }
//    public Geography(){
//        id = 0;
//        name = "";
//        type = "";
//        code = "";
//        parentId = 0;
//    }

    public int getId(){
        return id;
    }
    public void getName(){
        System.out.println(name);
    }
    public void getType(){
        System.out.println(type);
    }
    public void getCode(){
        System.out.println(code);
    }
    public int getParentId(){
        return parentId;
    }

    public void setId(int i) {
        this.id = i;
    }

    public void setCode(String ab) {
        this.code = ab;
    }

    public void setName(String xyz) {
        this.name = xyz;
    }

    public void setParentId(Integer o) {
        this.parentId = o;
    }
}
