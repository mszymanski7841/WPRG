package org.example.model.abstraction;

public interface IHaveHierarchicalStructure<TResult> {




}
