package org.example.tools.geographies;

import org.example.Geography;
import org.example.tools.abstractions.IParse;

public class GeographyParser implements IParse<Geography> {


    @Override
    public Geography parse(String line) {
        return null;
    }




}
