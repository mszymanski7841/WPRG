package com.pjatk.MPR;

import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class MyRestService {
    public static void main(String[] args) {
        List<Car> cars = new ArrayList<>();
        cars.add(new Car(1, "Honda", "Civic", 2022));
        cars.add(new Car(2, "Pagani", "Zonda", 2014));
        cars.add(new Car(3, "BMW", "E46", 2006));

    }



}
