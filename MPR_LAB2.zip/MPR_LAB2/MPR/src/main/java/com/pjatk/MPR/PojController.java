package com.pjatk.MPR;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class PojController {

    private final MyRestService myRestService;
    @Autowired
    public PojController(MyRestService myRestService) {
        this.myRestService = myRestService;
    }


    @GetMapping("/greeting")
    public String greeting(){
        return "Greeting from Spring Boot.";
    }

    @GetMapping("/greeting/id")
    public List<Car>


}
