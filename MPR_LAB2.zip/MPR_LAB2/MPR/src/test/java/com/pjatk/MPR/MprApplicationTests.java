package com.pjatk.MPR;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MprApplicationTests {

	@Test
	void contextLoads() {
	}

}
