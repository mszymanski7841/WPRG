package com.pjatk.MPR;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockitoAnnotations;

public class PojControllerTest {
    private CarRepository repository;
    private AutoCloseable openMocks;
    private PojController pojController;
    private MyRestService myRestService;

    @BeforeEach
    public void init(){
        openMocks = MockitoAnnotations.openMocks(this);
        pojController = new PojController(myRestService);
    }
    @AfterEach
    public void close() throws Exception {
        openMocks.close();
    }
    @Test
    public void testGetById() {
        Long id = 0L;
        pojController.getById(id);
    }
}
