package com.pjatk.MPR;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class MyRestService {
    private CarRepository repository;

    @Autowired
    public MyRestService(CarRepository repository) {
        this.repository = repository;
        this.repository.save(new Car("Mazda", "RX-7", 2004));
        this.repository.save(new Car("Honda", "Civic", 2001));
    }

    public Car findCarByMake(String make) {
        return this.repository.findByMake(make);
    }

    public List<Car> findAll() {
        return (List<Car>) this.repository.findAll();
    }
    public Optional<Car> findById(Long id){
        return this.repository.findById(id);
    }

    public void addCar(Car car) {
        this.repository.save(car);
    }
}
